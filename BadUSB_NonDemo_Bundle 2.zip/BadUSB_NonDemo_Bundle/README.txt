BadUSB Bundle

Included:
1. Windows CMD "hi" test
2. iPad text-field "hi" test
3. 0910 typing test
4. iPad keyboard-navigation test
5. iPad Spotlight "OFF" shortcut launcher
6. Discord Test DM (/testdm)
7. Dolphin CMD ASCII payload (partial recovered version)
8. Windows immediate shutdown payload

Note: The dolphin payload is only partially recoverable from the current conversation context,
so its file includes the recovered beginning plus a placeholder comment for the remaining ASCII art.

Use only on devices you own or have permission to test.
