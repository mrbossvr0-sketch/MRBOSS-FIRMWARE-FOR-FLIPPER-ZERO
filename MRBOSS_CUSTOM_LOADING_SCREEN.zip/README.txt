MRBOSS CUSTOM LOADING SCREEN
===========================

This is NOT a firmware update. It is a safe standalone Momentum JavaScript screen.

INSTALL:
1. Extract this ZIP.
2. Copy the contents to the ROOT of your Flipper SD card.
   It should create:
     /apps/Scripts/MRBOSS_Loading.js
     /apps_data/mrboss/mrboss.fxbm
3. On the Flipper, open Apps -> Scripts -> MRBOSS_Loading.js.
4. Your custom MRBOSS screen fills the 128x64 display.
5. Press BACK to close it.

Note: The Flipper Zero display is monochrome, so the original purple image is converted to black and white.
