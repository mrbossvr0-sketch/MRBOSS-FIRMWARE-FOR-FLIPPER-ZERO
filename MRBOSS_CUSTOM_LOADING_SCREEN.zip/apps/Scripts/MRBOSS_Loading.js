// MRBOSS Custom Loading Screen
// Made for Momentum firmware JavaScript support.
// Press BACK to close.

let eventLoop = require("event_loop");
let gui = require("gui");
let widget = require("gui/widget");
let icon = require("gui/icon");

let mrbossImage = icon.loadFxbm("/ext/apps_data/mrboss/mrboss.fxbm");

let screen = widget.makeWith({}, [
    { element: "icon", x: 0, y: 0, iconData: mrbossImage },
]);

// Back button exits the splash screen.
eventLoop.subscribe(gui.viewDispatcher.navigation, function (_sub, _item, eventLoop) {
    eventLoop.stop();
}, eventLoop);

gui.viewDispatcher.switchTo(screen);
eventLoop.run();
